class PasswordResetsController < ApplicationController
  def new
  end

  def edit
  end
end
