class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception
<<<<<<< HEAD


=======
  include SessionsHelper
  
>>>>>>> c9081a57060910e5234a41662c3cfd98773c8598
end
